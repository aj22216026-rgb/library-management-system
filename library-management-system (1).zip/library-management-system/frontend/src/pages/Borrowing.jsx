import React, { useState, useEffect } from 'react';
import {
  Typography,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Box,
  Chip,
  IconButton,
  Grid,
  Alert,
} from '@mui/material';
import { Add, Undo, Warning } from '@mui/icons-material';
import { booksApi, membersApi, borrowingApi } from '../services/api';
import { useSnackbar } from 'notistack';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import DialogContentText from '@mui/material/DialogContentText';

const Borrowing = () => {
  const [borrowingRecords, setBorrowingRecords] = useState([]);
  const [books, setBooks] = useState([]);
  const [members, setMembers] = useState([]);
  const [open, setOpen] = useState(false);
  const [returnDialogOpen, setReturnDialogOpen] = useState(false);
  const [recordToReturn, setRecordToReturn] = useState(null);
  const [overdueBooks, setOverdueBooks] = useState([]);
  const { enqueueSnackbar } = useSnackbar();
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    bookId: '',
    memberId: '',
  });

  useEffect(() => {
    if (loading) return;

    if (!user) {
      navigate('/login');
      return;
    }
    const isAdmin = user?.roles?.includes('ROLE_ADMIN');
    if (!isAdmin) {
      enqueueSnackbar('Access denied: Admin privileges required', { variant: 'error' });
      navigate('/');
      return;
    }
    loadData();
  }, [user, loading]);

  const loadData = async () => {
    try {
      const [borrowingResponse, booksResponse, membersResponse, overdueResponse] = await Promise.all([
        borrowingApi.getActive(),
        booksApi.getAvailable(),
        membersApi.getActive(),
        borrowingApi.getOverdue(),
      ]);
      setBorrowingRecords(borrowingResponse.data);
      setBooks(booksResponse.data);
      setMembers(membersResponse.data);
      setOverdueBooks(overdueResponse.data);
    } catch (error) {
      if (error.response?.status === 401 || error.response?.status === 403) {
        enqueueSnackbar('You must be logged in to view this page', { variant: 'error' });
        navigate('/login');
      } else {
        enqueueSnackbar('Error loading borrowing data', { variant: 'error' });
      }
    }
  };

  const handleOpenDialog = () => {
    setFormData({ bookId: '', memberId: '' });
    setOpen(true);
  };

  const handleCloseDialog = () => {
    setOpen(false);
  };

  const handleBorrow = async () => {
    try {
      await borrowingApi.borrow(formData.bookId, formData.memberId);
      enqueueSnackbar('Book borrowed successfully', { variant: 'success' });
      handleCloseDialog();
      loadData();
    } catch (error) {
      enqueueSnackbar(error.response?.data || 'Error borrowing book', { variant: 'error' });
    }
  };

  const handleReturnClick = (record) => {
    setRecordToReturn(record);
    setReturnDialogOpen(true);
  };

  const confirmReturn = async () => {
    if (!recordToReturn) return;
    try {
      const response = await borrowingApi.return(recordToReturn.id);
      const record = response.data;
      if (record.fineAmount > 0) {
        enqueueSnackbar(`Book returned successfully. Fine: $${record.fineAmount.toFixed(2)}`, { variant: 'warning' });
      } else {
        enqueueSnackbar('Book returned successfully', { variant: 'success' });
      }
      loadData();
    } catch (error) {
      enqueueSnackbar('Error returning book', { variant: 'error' });
    } finally {
      setReturnDialogOpen(false);
      setRecordToReturn(null);
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  if (!user) return null;

  return (
    <Box sx={{ width: '100%', flexGrow: 1, display: 'flex', flexDirection: 'column' }} className="fade-in">
      <Box sx={{ 
        mb: 6, 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'flex-end',
        width: '100%'
      }}>
        <Box>
            <Typography variant="h3" gutterBottom sx={{ fontWeight: 1000, color: 'primary.main' }}>
                Cham's Circulation Hub
            </Typography>
            <Typography variant="h6" color="text.secondary" sx={{ fontWeight: 400 }}>
                Monitor and control the flow of books through your library network.
            </Typography>
        </Box>
        <Button 
          variant="contained" 
          size="large"
          startIcon={<Add />} 
          onClick={handleOpenDialog}
          sx={{ py: 1.8, px: 4, borderRadius: '10px' }}
        >
          Issue New Loan
        </Button>
      </Box>

      {/* Statistics Cards */}
      <Grid container spacing={4} sx={{ mb: 6 }}>
        <Grid item xs={12} md={4}>
          <Paper sx={{ 
            p: 4, 
            borderRadius: '24px', 
            bgcolor: 'white',
            display: 'flex',
            flexDirection: 'column',
            gap: 1,
            border: '1px solid #e2e8f0'
          }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Box sx={{ width: 12, height: 12, borderRadius: '50%', bgcolor: 'secondary.main' }} />
              <Typography variant="overline" sx={{ fontWeight: 800, color: 'text.secondary', letterSpacing: 1.5 }}>ACTIVE LOANS</Typography>
            </Box>
            <Typography variant="h2" sx={{ fontWeight: 900, color: 'primary.main' }}>
              {borrowingRecords.length}
            </Typography>
            <Typography variant="body2" color="text.secondary">Books currently with members</Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} md={4}>
          <Paper sx={{ 
            p: 4, 
            borderRadius: '24px', 
            bgcolor: 'white',
            display: 'flex',
            flexDirection: 'column',
            gap: 1,
            border: '1px solid #e2e8f0'
          }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Box sx={{ width: 12, height: 12, borderRadius: '50%', bgcolor: 'success.main' }} />
              <Typography variant="overline" sx={{ fontWeight: 800, color: 'text.secondary', letterSpacing: 1.5 }}>AVAILABLE STOCK</Typography>
            </Box>
            <Typography variant="h2" sx={{ fontWeight: 900, color: 'primary.main' }}>
              {books.length}
            </Typography>
            <Typography variant="body2" color="text.secondary">Ready for new checkouts</Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} md={4}>
          <Paper sx={{ 
            p: 4, 
            borderRadius: '24px', 
            bgcolor: 'white',
            display: 'flex',
            flexDirection: 'column',
            gap: 1,
            border: '1px solid #e2e8f0'
          }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Box sx={{ width: 12, height: 12, borderRadius: '50%', bgcolor: 'error.main' }} />
              <Typography variant="overline" sx={{ fontWeight: 800, color: 'text.secondary', letterSpacing: 1.5 }}>OVERDUE ITEMS</Typography>
            </Box>
            <Typography variant="h2" sx={{ fontWeight: 900, color: 'primary.main' }}>
              {overdueBooks.length}
            </Typography>
            <Typography variant="body2" color="text.secondary">Requires immediate attention</Typography>
          </Paper>
        </Grid>
      </Grid>

      {overdueBooks.length > 0 && (
        <Alert 
          severity="error" 
          icon={<Warning sx={{ fontSize: '2rem' }} />}
          sx={{ 
            mb: 5, 
            borderRadius: '16px', 
            py: 2,
            px: 3,
            bgcolor: '#fef2f2',
            border: '1px solid #fee2e2',
            '& .MuiAlert-message': { width: '100%' } 
          }}
        >
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Typography variant="h6" sx={{ fontWeight: 700, color: '#991b1b' }}>
              Attention Needed: {overdueBooks.length} items are past their return date!
            </Typography>
            <Button color="error" variant="contained" size="small" sx={{ fontWeight: 800 }}>Notify Members</Button>
          </Box>
        </Alert>
      )}

      {/* Records Table */}
      <TableContainer 
        component={Paper} 
        sx={{ 
          borderRadius: '20px', 
          overflow: 'hidden',
          flexGrow: 1,
          border: '1px solid #e2e8f0',
          boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.05), 0 4px 6px -4px rgb(0 0 0 / 0.05)'
        }}
      >
        <Table stickyHeader>
          <TableHead>
            <TableRow>
              <TableCell sx={{ bgcolor: 'primary.main', color: 'white', fontWeight: 700, py: 2.5 }}>BOOK TITLE</TableCell>
              <TableCell sx={{ bgcolor: 'primary.main', color: 'white', fontWeight: 700 }}>MEMBER NAME</TableCell>
              <TableCell sx={{ bgcolor: 'primary.main', color: 'white', fontWeight: 700 }}>BORROW DATE</TableCell>
              <TableCell sx={{ bgcolor: 'primary.main', color: 'white', fontWeight: 700 }}>DUE DATE</TableCell>
              <TableCell sx={{ bgcolor: 'primary.main', color: 'white', fontWeight: 700 }}>CIRCULATION STATUS</TableCell>
              <TableCell sx={{ bgcolor: 'primary.main', color: 'white', fontWeight: 700, textAlign: 'right', pr: 4 }}>OPERATIONS</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {borrowingRecords.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} align="center" sx={{ py: 15 }}>
                  <Typography variant="h5" color="text.secondary">
                    No books are currently on loan
                  </Typography>
                </TableCell>
              </TableRow>
            ) : (
              borrowingRecords.map((record) => {
                const isOverdue = new Date(record.dueDate) < new Date();
                return (
                  <TableRow key={record.id} hover sx={{ transition: 'background-color 0.2s' }}>
                    <TableCell sx={{ py: 3 }}>
                      <Typography variant="subtitle1" sx={{ color: 'primary.main', fontWeight: 700 }}>{record.bookTitle || 'N/A'}</Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>{record.memberName || 'N/A'}</Typography>
                    </TableCell>
                    <TableCell>{formatDate(record.borrowDate)}</TableCell>
                    <TableCell>
                      <Typography variant="body2" sx={{ color: isOverdue ? 'error.main' : 'text.primary', fontWeight: isOverdue ? 700 : 400 }}>
                        {formatDate(record.dueDate)}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Chip
                        label={isOverdue ? 'CRITICAL: OVERDUE' : 'ON LOAN'}
                        sx={{ 
                          fontWeight: 800, 
                          minWidth: 140,
                          bgcolor: isOverdue ? '#fff1f2' : '#eff6ff',
                          color: isOverdue ? '#e11d48' : '#2563eb',
                          fontSize: '0.75rem'
                        }}
                      />
                    </TableCell>
                    <TableCell align="right" sx={{ pr: 3 }}>
                      <Button
                        variant="contained"
                        color="primary"
                        startIcon={<Undo />}
                        onClick={() => handleReturnClick(record)}
                        size="small"
                        sx={{ borderRadius: '8px', py: 1, px: 2, fontWeight: 700 }}
                      >
                        Return Item
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Borrow Dialog */}
      <Dialog 
        open={open} 
        onClose={handleCloseDialog} 
        maxWidth="sm" 
        fullWidth
        PaperProps={{ sx: { borderRadius: 4, p: 1 } }}
      >
        <DialogTitle sx={{ fontWeight: 800, fontSize: '1.5rem' }}>Issue New Publication Loan</DialogTitle>
        <DialogContent>
          <Box sx={{ pt: 2, display: 'flex', flexDirection: 'column', gap: 3 }}>
            <FormControl fullWidth sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }}>
              <InputLabel>Select Book</InputLabel>
              <Select
                value={formData.bookId}
                onChange={(e) => setFormData({ ...formData, bookId: e.target.value })}
                label="Select Book"
              >
                {books.map((book) => (
                  <MenuItem key={book.id} value={book.id}>
                    {book.title} (ISBN: {book.isbn})
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl fullWidth sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }}>
              <InputLabel>Select Member</InputLabel>
              <Select
                value={formData.memberId}
                onChange={(e) => setFormData({ ...formData, memberId: e.target.value })}
                label="Select Member"
              >
                {members.map((member) => (
                  <MenuItem key={member.id} value={member.id}>
                    {member.name} ({member.email})
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Box>
        </DialogContent>
        <DialogActions sx={{ p: 3, pt: 1 }}>
          <Button onClick={handleCloseDialog} color="inherit" sx={{ fontWeight: 700 }}>Cancel</Button>
          <Button
            onClick={handleBorrow}
            variant="contained"
            disabled={!formData.bookId || !formData.memberId}
            sx={{ fontWeight: 800, px: 4, borderRadius: 2 }}
          >
            Issue Loan
          </Button>
        </DialogActions>
      </Dialog>

      {/* Return Confirmation Dialog */}
      <Dialog
        open={returnDialogOpen}
        onClose={() => setReturnDialogOpen(false)}
        PaperProps={{
          sx: { borderRadius: 4, p: 1 }
        }}
      >
        <DialogTitle sx={{ fontWeight: 800 }}>Confirm Return</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to mark <strong>{recordToReturn?.book.title}</strong> as returned by <strong>{recordToReturn?.member.name}</strong>?
          </DialogContentText>
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button onClick={() => setReturnDialogOpen(false)} color="inherit" sx={{ fontWeight: 700 }}>
            Cancel
          </Button>
          <Button onClick={confirmReturn} variant="contained" color="primary" sx={{ fontWeight: 800, px: 3 }}>
            Return Book
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Borrowing;