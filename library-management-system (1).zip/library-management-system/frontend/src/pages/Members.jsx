import React, { useState, useEffect } from 'react';
import {
  Typography,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Box,
  Chip,
  IconButton,
} from '@mui/material';
import { Add, Edit, Delete, Search } from '@mui/icons-material';
import { membersApi } from '../services/api';
import { useSnackbar } from 'notistack';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import DialogContentText from '@mui/material/DialogContentText';

const Members = () => {
  const [members, setMembers] = useState([]);
  const [open, setOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [memberToDelete, setMemberToDelete] = useState(null);
  const [editingMember, setEditingMember] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const { enqueueSnackbar } = useSnackbar();
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phoneNumber: '',
    address: '',
  });

  useEffect(() => {
    if (loading) return;

    if (!user) {
      navigate('/login');
      return;
    }
    const isAdmin = user?.roles?.includes('ROLE_ADMIN');
    if (!isAdmin) {
      enqueueSnackbar('Access denied: Admin privileges required', { variant: 'error' });
      navigate('/');
      return;
    }
    loadMembers();
  }, [user, loading]);

  const loadMembers = async () => {
    try {
      const response = await membersApi.getAll();
      setMembers(response.data);
    } catch (error) {
      if (error.response?.status === 401 || error.response?.status === 403) {
        enqueueSnackbar('You must be logged in to view members', { variant: 'error' });
        navigate('/login');
      } else {
        enqueueSnackbar('Error loading members', { variant: 'error' });
      }
    }
  };

  const handleSearch = async () => {
    if (!searchTerm.trim()) {
      loadMembers();
      return;
    }
    try {
      const response = await membersApi.search(searchTerm);
      setMembers(response.data);
    } catch (error) {
      enqueueSnackbar('Error searching members', { variant: 'error' });
    }
  };

  const handleOpenDialog = (member = null) => {
    setEditingMember(member);
    if (member) {
      setFormData({
        name: member.name,
        email: member.email,
        phoneNumber: member.phoneNumber,
        address: member.address || '',
      });
    } else {
      setFormData({
        name: '',
        email: '',
        phoneNumber: '',
        address: '',
      });
    }
    setOpen(true);
  };

  const handleCloseDialog = () => {
    setOpen(false);
    setEditingMember(null);
  };

  const handleSubmit = async () => {
    if (!formData.name || !formData.email || !formData.phoneNumber) {
        enqueueSnackbar('Name, Email and Phone are required', { variant: 'warning' });
        return;
    }

    try {
      if (editingMember) {
        await membersApi.update(editingMember.id, formData);
        enqueueSnackbar('Member profile updated successfully', { variant: 'success' });
      } else {
        await membersApi.create(formData);
        enqueueSnackbar('Member registered successfully', { variant: 'success' });
      }
      handleCloseDialog();
      loadMembers();
    } catch (error) {
      if (error.response?.status === 403) {
        enqueueSnackbar('You do not have permission to modify members', { variant: 'error' });
      } else {
        enqueueSnackbar('Error saving member data', { variant: 'error' });
      }
    }
  };

  const handleDeleteClick = (member) => {
    setMemberToDelete(member);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = async () => {
    if (!memberToDelete) return;
    try {
      await membersApi.delete(memberToDelete.id);
      enqueueSnackbar('Member account deleted successfully', { variant: 'success' });
      loadMembers();
    } catch (error) {
      if (error.response?.status === 403) {
        enqueueSnackbar('Only administrators can delete members', { variant: 'error' });
      } else {
        enqueueSnackbar('Error deleting member', { variant: 'error' });
      }
    } finally {
      setDeleteDialogOpen(false);
      setMemberToDelete(null);
    }
  };

  const isAdmin = user?.roles?.includes('ROLE_ADMIN');

  if (!user) return null;

  return (
    <Box sx={{ width: '100%', flexGrow: 1, display: 'flex', flexDirection: 'column' }} className="fade-in">
      <Box sx={{ 
        mb: 6, 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'flex-end',
        width: '100%'
      }}>
        <Box>
            <Typography variant="h3" gutterBottom sx={{ fontWeight: 1000, color: 'primary.main' }}>
                Member Registry
            </Typography>
            <Typography variant="h6" color="text.secondary" sx={{ fontWeight: 400 }}>
                Manage the registered patrons and active readers of Cham's Library.
            </Typography>
        </Box>
        {isAdmin && (
          <Button 
            variant="contained" 
            size="large"
            startIcon={<Add />} 
            onClick={() => handleOpenDialog()}
            sx={{ py: 1.8, px: 4, borderRadius: '10px' }}
          >
            Register New Patron
          </Button>
        )}
      </Box>

      <Paper sx={{ 
        p: 1.5, 
        mb: 5, 
        display: 'flex', 
        gap: 2, 
        alignItems: 'center', 
        borderRadius: '16px',
        bgcolor: 'white',
        border: '1px solid #e2e8f0',
        boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05)'
      }}>
        <TextField
          fullWidth
          placeholder="Search members by name or email address..."
          variant="standard"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
          InputProps={{
            disableUnderline: true,
            startAdornment: <Search color="action" sx={{ ml: 2, mr: 2, fontSize: '1.5rem' }} />,
          }}
          sx={{ height: 50, display: 'flex', justifyContent: 'center' }}
        />
        <Button 
          variant="contained" 
          onClick={handleSearch}
          color="secondary"
          sx={{ height: 50, px: 5, borderRadius: '10px' }}
        >
          Lookup Patron
        </Button>
      </Paper>

      <TableContainer 
        component={Paper} 
        sx={{ 
          borderRadius: '20px', 
          overflow: 'hidden',
          flexGrow: 1,
          border: '1px solid #e2e8f0',
          boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.05), 0 4px 6px -4px rgb(0 0 0 / 0.05)'
        }}
      >
        <Table stickyHeader>
          <TableHead>
            <TableRow>
              <TableCell sx={{ bgcolor: 'primary.main', color: 'white', fontWeight: 700, py: 2.5 }}>PATRON NAME</TableCell>
              <TableCell sx={{ bgcolor: 'primary.main', color: 'white', fontWeight: 700 }}>EMAIL ADDRESS</TableCell>
              <TableCell sx={{ bgcolor: 'primary.main', color: 'white', fontWeight: 700 }}>TELEPHONE</TableCell>
              <TableCell sx={{ bgcolor: 'primary.main', color: 'white', fontWeight: 700 }}>RESIDENCE</TableCell>
              <TableCell sx={{ bgcolor: 'primary.main', color: 'white', fontWeight: 700 }}>STATUS</TableCell>
              <TableCell sx={{ bgcolor: 'primary.main', color: 'white', fontWeight: 700, textAlign: 'right', pr: 4 }}>OPERATIONS</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {members.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} align="center" sx={{ py: 15 }}>
                  <Typography variant="h5" color="text.secondary">
                    No registered members found
                  </Typography>
                </TableCell>
              </TableRow>
            ) : (
              members.map((member) => (
                <TableRow key={member.id} hover sx={{ transition: 'background-color 0.2s' }}>
                  <TableCell sx={{ py: 3 }}>
                    <Typography variant="subtitle1" sx={{ color: 'primary.main', fontWeight: 700 }}>{member.name}</Typography>
                  </TableCell>
                  <TableCell>{member.email}</TableCell>
                  <TableCell sx={{ fontFamily: 'monospace' }}>{member.phoneNumber}</TableCell>
                  <TableCell>
                    <Typography variant="body2" color="text.secondary">{member.address || 'N/A'}</Typography>
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={member.active ? 'VERIFIED' : 'DEACTIVATED'}
                      sx={{ 
                        fontWeight: 800, 
                        minWidth: 120,
                        bgcolor: member.active ? '#ecfdf5' : '#fff1f2',
                        color: member.active ? '#059669' : '#e11d48',
                        fontSize: '0.7rem'
                      }}
                    />
                  </TableCell>
                  <TableCell align="right" sx={{ pr: 3 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 1 }}>
                        <IconButton 
                            color="primary" 
                            onClick={() => handleOpenDialog(member)} 
                            sx={{ bgcolor: '#f1f5f9', '&:hover': { bgcolor: '#e2e8f0' } }}
                        >
                            <Edit fontSize="small" />
                        </IconButton>
                        {isAdmin && (
                            <IconButton 
                                color="error" 
                                onClick={() => handleDeleteClick(member)} 
                                sx={{ bgcolor: '#fef2f2', '&:hover': { bgcolor: '#fee2e2' } }}
                            >
                                <Delete fontSize="small" />
                            </IconButton>
                        )}
                    </Box>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog 
        open={open} 
        onClose={handleCloseDialog} 
        maxWidth="sm" 
        fullWidth
        PaperProps={{ sx: { borderRadius: 4, p: 1 } }}
      >
        <DialogTitle sx={{ fontWeight: 800, fontSize: '1.5rem' }}>
            {editingMember ? 'Update Patron Record' : 'Register New Library Patron'}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ pt: 2, display: 'flex', flexDirection: 'column', gap: 2.5 }}>
            <TextField
              label="Full Name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
              fullWidth
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }}
            />
            <TextField
              label="Email Address"
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              required
              fullWidth
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }}
            />
            <TextField
              label="Phone Number"
              value={formData.phoneNumber}
              onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
              required
              fullWidth
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }}
            />
            <TextField
              label="Residential Address"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              multiline
              rows={3}
              fullWidth
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }}
            />
          </Box>
        </DialogContent>
        <DialogActions sx={{ p: 3, pt: 1 }}>
          <Button onClick={handleCloseDialog} color="inherit" sx={{ fontWeight: 700 }}>Cancel</Button>
          <Button onClick={handleSubmit} variant="contained" sx={{ fontWeight: 800, px: 4, borderRadius: 2 }}>
            {editingMember ? 'Save Profile' : 'Register Patron'}
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog
        open={deleteDialogOpen}
        onClose={() => setDeleteDialogOpen(false)}
        PaperProps={{ sx: { borderRadius: 4, p: 1 } }}
      >
        <DialogTitle sx={{ fontWeight: 800 }}>Confirm Deactivation</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to remove <strong>{memberToDelete?.name}</strong> from the system? This action will prevent them from borrowing books.
          </DialogContentText>
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button onClick={() => setDeleteDialogOpen(false)} color="inherit" sx={{ fontWeight: 700 }}>
            Cancel
          </Button>
          <Button onClick={confirmDelete} variant="contained" color="error" sx={{ fontWeight: 800, px: 3 }}>
            Delete Permanently
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Members;