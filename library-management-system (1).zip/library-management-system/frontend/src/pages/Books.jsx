import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Box,
  Chip,
  IconButton,
} from '@mui/material';
import { Add, Edit, Delete, Search } from '@mui/icons-material';
import { booksApi } from '../services/api';
import { useSnackbar } from 'notistack';
import { useAuth } from '../context/AuthContext';
import DialogContentText from '@mui/material/DialogContentText';

const Books = () => {
  const [books, setBooks] = useState([]);
  const [open, setOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [bookToDelete, setBookToDelete] = useState(null);
  const [editingBook, setEditingBook] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const { enqueueSnackbar } = useSnackbar();
  const { user } = useAuth();
  
  const [formData, setFormData] = useState({
    title: '',
    author: '',
    isbn: '',
    genre: '',
    publicationYear: '',
    description: '',
  });

  useEffect(() => {
    loadBooks();
  }, []);

  const loadBooks = async () => {
    try {
      const response = await booksApi.getAll();
      setBooks(response.data);
    } catch (error) {
      enqueueSnackbar('Error loading books', { variant: 'error' });
    }
  };

  const handleSearch = async () => {
    if (!searchTerm.trim()) {
      loadBooks();
      return;
    }
    try {
      const response = await booksApi.search(searchTerm);
      setBooks(response.data);
    } catch (error) {
      enqueueSnackbar('Error searching books', { variant: 'error' });
    }
  };

  const handleOpenDialog = (book = null) => {
    setEditingBook(book);
    if (book) {
      setFormData({
        title: book.title,
        author: book.author,
        isbn: book.isbn,
        genre: book.genre,
        publicationYear: book.publicationYear,
        description: book.description || '',
      });
    } else {
      setFormData({
        title: '',
        author: '',
        isbn: '',
        genre: '',
        publicationYear: '',
        description: '',
      });
    }
    setOpen(true);
  };

  const handleCloseDialog = () => {
    setOpen(false);
    setEditingBook(null);
  };

  const handleSubmit = async () => {
    // Basic validation
    if (!formData.title || !formData.author || !formData.isbn) {
        enqueueSnackbar('Title, Author and ISBN are required', { variant: 'warning' });
        return;
    }

    try {
      const bookData = {
        ...formData,
        publicationYear: parseInt(formData.publicationYear),
      };

      if (editingBook) {
        await booksApi.update(editingBook.id, bookData);
        enqueueSnackbar('Book updated successfully', { variant: 'success' });
      } else {
        await booksApi.create(bookData);
        enqueueSnackbar('Book added successfully', { variant: 'success' });
      }
      handleCloseDialog();
      loadBooks();
    } catch (error) {
      if (error.response?.status === 403) {
        enqueueSnackbar('You do not have permission to perform this action', { variant: 'error' });
      } else {
        enqueueSnackbar('Error saving book', { variant: 'error' });
      }
    }
  };

  const handleDeleteClick = (book) => {
    setBookToDelete(book);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = async () => {
    if (!bookToDelete) return;
    try {
      await booksApi.delete(bookToDelete.id);
      enqueueSnackbar('Book deleted successfully', { variant: 'success' });
      loadBooks();
    } catch (error) {
      if (error.response?.status === 403) {
        enqueueSnackbar('Only admins can delete books', { variant: 'error' });
      } else {
        enqueueSnackbar('Error deleting book', { variant: 'error' });
      }
    } finally {
      setDeleteDialogOpen(false);
      setBookToDelete(null);
    }
  };

  const isAdmin = user?.roles?.includes('ROLE_ADMIN');
  const isUser = user?.roles?.includes('ROLE_USER') || isAdmin;

  return (
    <Box sx={{ width: '100%', flexGrow: 1, display: 'flex', flexDirection: 'column' }} className="fade-in">
      <Box sx={{ 
        mb: 6, 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'flex-end',
        width: '100%'
      }}>
        <Box>
            <Typography variant="h3" gutterBottom sx={{ fontWeight: 1000, color: 'primary.main' }}>
                Cham's Library Collection
            </Typography>
            <Typography variant="h6" color="text.secondary" sx={{ fontWeight: 400 }}>
                Curate and organize your digital catalog of {books.length} publications.
            </Typography>
        </Box>
        {isUser && (
            <Button 
                variant="contained" 
                size="large"
                startIcon={<Add />} 
                onClick={() => handleOpenDialog()}
                sx={{ py: 1.8, px: 4, borderRadius: '10px' }}
            >
                Catalog New Book
            </Button>
        )}
      </Box>

      <Paper sx={{ 
        p: 1.5, 
        mb: 5, 
        display: 'flex', 
        gap: 2, 
        alignItems: 'center', 
        borderRadius: '16px',
        bgcolor: 'white',
        boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05)'
      }}>
        <TextField
          fullWidth
          placeholder="Search by title, author, or ISBN..."
          variant="standard"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
          InputProps={{
            disableUnderline: true,
            startAdornment: <Search color="action" sx={{ ml: 2, mr: 2, fontSize: '1.5rem' }} />,
          }}
          sx={{ height: 50, display: 'flex', justifyContent: 'center' }}
        />
        <Button 
          variant="contained" 
          onClick={handleSearch}
          color="secondary"
          sx={{ height: 50, px: 5, borderRadius: '10px' }}
        >
          Find Book
        </Button>
      </Paper>

      <TableContainer 
        component={Paper} 
        sx={{ 
          borderRadius: '16px',
          overflow: 'hidden',
          border: '1px solid #e2e8f0',
          mb: 4
        }}
      >
        <Table>
          <TableHead sx={{ bgcolor: 'primary.main' }}>
            <TableRow>
              <TableCell sx={{ color: 'white', fontWeight: 700, py: 2.5 }}>Title</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>Author</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>Genre</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>ISBN</TableCell>
              <TableCell sx={{ color: 'white', fontWeight: 700 }}>Status</TableCell>
              {(isUser || isAdmin) && <TableCell align="right" sx={{ color: 'white', fontWeight: 700 }}>Actions</TableCell>}
            </TableRow>
          </TableHead>
          <TableBody>
            {books.map((book) => (
              <TableRow 
                key={book.id}
                hover
                sx={{ 
                  '&:last-child td, &:last-child th': { border: 0 },
                  transition: 'background-color 0.2s',
                  '&:hover': { bgcolor: '#f1f5f9' }
                }}
              >
                <TableCell sx={{ py: 3, fontWeight: 600 }}>{book.title}</TableCell>
                <TableCell>{book.author}</TableCell>
                <TableCell>
                  <Chip label={book.genre} size="small" variant="outlined" sx={{ fontWeight: 600 }} />
                </TableCell>
                <TableCell sx={{ fontFamily: 'monospace', color: 'text.secondary' }}>{book.isbn}</TableCell>
                <TableCell>
                  <Chip 
                    label={book.available ? 'Available' : 'Borrowed'} 
                    color={book.available ? 'success' : 'warning'}
                    sx={{ fontWeight: 700, borderRadius: '6px' }}
                  />
                </TableCell>
                {(isUser || isAdmin) && (
                  <TableCell align="right">
                    <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 1 }}>
                      <IconButton 
                        size="small" 
                        color="primary"
                        onClick={() => handleOpenDialog(book)}
                        sx={{ bgcolor: '#f1f5f9', '&:hover': { bgcolor: '#e2e8f0' } }}
                      >
                        <Edit fontSize="small" />
                      </IconButton>
                      {isAdmin && (
                        <IconButton 
                          size="small" 
                          color="error"
                          onClick={() => handleDeleteClick(book)}
                          sx={{ bgcolor: '#fef2f2', '&:hover': { bgcolor: '#fee2e2' } }}
                        >
                          <Delete fontSize="small" />
                        </IconButton>
                      )}
                    </Box>
                  </TableCell>
                )}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Existing Book Dialog */}
      <Dialog 
        open={open} 
        onClose={handleCloseDialog} 
        maxWidth="sm" 
        fullWidth
        PaperProps={{
          sx: { borderRadius: 4, p: 1 }
        }}
      >
        <DialogTitle sx={{ fontWeight: 800, fontSize: '1.5rem', pb: 1 }}>
          {editingBook ? 'Update Book Metadata' : 'Catalog New Publication'}
        </DialogTitle>
        <DialogContent>
          <Box sx={{ pt: 2, display: 'flex', flexDirection: 'column', gap: 2.5 }}>
            <TextField
              label="Title"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              required
              fullWidth
              variant="outlined"
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }}
            />
            <Box sx={{ display: 'flex', gap: 2 }}>
                <TextField
                label="Author"
                value={formData.author}
                onChange={(e) => setFormData({ ...formData, author: e.target.value })}
                required
                fullWidth
                variant="outlined"
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }}
                />
                <TextField
                label="Genre"
                value={formData.genre}
                onChange={(e) => setFormData({ ...formData, genre: e.target.value })}
                required
                fullWidth
                variant="outlined"
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }}
                />
            </Box>
            <Box sx={{ display: 'flex', gap: 2 }}>
                <TextField
                label="ISBN"
                value={formData.isbn}
                onChange={(e) => setFormData({ ...formData, isbn: e.target.value })}
                required
                fullWidth
                variant="outlined"
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }}
                />
                <TextField
                label="Publication Year"
                type="number"
                value={formData.publicationYear}
                onChange={(e) => setFormData({ ...formData, publicationYear: e.target.value })}
                required
                fullWidth
                variant="outlined"
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }}
                />
            </Box>
            <TextField
              label="Description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              multiline
              rows={4}
              fullWidth
              variant="outlined"
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: 2 } }}
            />
          </Box>
        </DialogContent>
        <DialogActions sx={{ p: 3, pt: 1 }}>
          <Button onClick={handleCloseDialog} color="inherit" sx={{ fontWeight: 700 }}>Cancel</Button>
          <Button 
            onClick={handleSubmit} 
            variant="contained" 
            sx={{ fontWeight: 800, px: 4, borderRadius: 2 }}
          >
            {editingBook ? 'Save Changes' : 'Catalog Book'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog
        open={deleteDialogOpen}
        onClose={() => setDeleteDialogOpen(false)}
        PaperProps={{
          sx: { borderRadius: 4, p: 1 }
        }}
      >
        <DialogTitle sx={{ fontWeight: 800 }}>Confim Deletion</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to delete <strong>{bookToDelete?.title}</strong>? This action cannot be undone.
          </DialogContentText>
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button onClick={() => setDeleteDialogOpen(false)} color="inherit" sx={{ fontWeight: 700 }}>
            Cancel
          </Button>
          <Button onClick={confirmDelete} variant="contained" color="error" sx={{ fontWeight: 700, px: 3 }}>
            Delete Permanently
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Books;