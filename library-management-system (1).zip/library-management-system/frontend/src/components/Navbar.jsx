import React from 'react';
import { AppBar, Toolbar, Typography, Button, Box, Container } from '@mui/material';
import { Link, useLocation } from 'react-router-dom';
import LibraryBooksIcon from '@mui/icons-material/LibraryBooks';
import MenuBookIcon from '@mui/icons-material/MenuBook';
import PeopleIcon from '@mui/icons-material/People';
import SwapHorizIcon from '@mui/icons-material/SwapHoriz';
import { useAuth } from '../context/AuthContext';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import LogoutIcon from '@mui/icons-material/Logout';
import LoginIcon from '@mui/icons-material/Login';
import PersonAddIcon from '@mui/icons-material/PersonAdd';

const Navbar = () => {
  const location = useLocation();
  const { user, logout } = useAuth();
  const isAdmin = user?.roles?.includes('ROLE_ADMIN');

  const navItems = [
    { label: 'Books', path: '/books', icon: <MenuBookIcon sx={{ mr: 1 }} /> },
    ...(isAdmin ? [
      { label: 'Members', path: '/members', icon: <PeopleIcon sx={{ mr: 1 }} /> },
      { label: 'Borrowing', path: '/borrowing', icon: <SwapHorizIcon sx={{ mr: 1 }} /> },
    ] : []),
  ];

  const isActive = (path) => {
    if (path === '/books' && (location.pathname === '/' || location.pathname === '/books')) return true;
    return location.pathname === path;
  };

  return (
    <AppBar 
      position="sticky" 
      elevation={0} 
      sx={{ 
        bgcolor: 'white', 
        borderBottom: '1px solid #e2e8f0',
        zIndex: (theme) => theme.zIndex.drawer + 1
      }}
    >
      <Container maxWidth={false} sx={{ px: { xs: 2, md: 4 } }}>
        <Toolbar disableGutters sx={{ height: 74 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mr: 8 }}>
            <LibraryBooksIcon sx={{ mr: 1.5, color: 'secondary.main', fontSize: '2.2rem' }} />
            <Typography
              variant="h5"
              noWrap
              component={Link}
              to="/"
              sx={{
                fontWeight: 1000,
                letterSpacing: '-0.02em',
                color: 'primary.main',
                textDecoration: 'none',
              }}
            >
              CHAM'S LIBRARY
            </Typography>
          </Box>

          <Box sx={{ flexGrow: 1, display: { xs: 'none', md: 'flex' }, gap: 1 }}>
            {user && navItems.map((item) => (
              <Button
                key={item.label}
                component={Link}
                to={item.path}
                startIcon={React.cloneElement(item.icon, { 
                  sx: { 
                    color: isActive(item.path) ? 'secondary.main' : 'text.secondary',
                    transition: 'color 0.2s'
                  } 
                })}
                sx={{
                  px: 2,
                  color: isActive(item.path) ? 'primary.main' : 'text.secondary',
                  fontSize: '0.95rem',
                  fontWeight: isActive(item.path) ? 700 : 500,
                  borderRadius: 0,
                  borderBottom: '3px solid',
                  borderColor: isActive(item.path) ? 'secondary.main' : 'transparent',
                  height: '100%',
                  transition: 'all 0.2s',
                  '&:hover': {
                    bgcolor: 'transparent',
                    color: 'primary.main',
                    borderColor: isActive(item.path) ? 'secondary.main' : '#e2e8f0',
                  },
                }}
              >
                {item.label}
              </Button>
            ))}
          </Box>

          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            {user ? (
              <>
                <Box sx={{ display: 'flex', alignItems: 'center', color: 'primary.main' }}>
                  <AccountCircleIcon sx={{ mr: 1 }} />
                  <Typography variant="body2" sx={{ fontWeight: 600 }}>
                    {user.username}
                  </Typography>
                </Box>
                <Button
                  onClick={logout}
                  variant="outlined"
                  startIcon={<LogoutIcon />}
                  sx={{
                    borderRadius: '12px',
                    px: 3,
                    textTransform: 'none',
                    fontWeight: 700,
                  }}
                >
                  Logout
                </Button>
              </>
            ) : (
              <>
                <Button
                  component={Link}
                  to="/login"
                  startIcon={<LoginIcon />}
                  sx={{
                    borderRadius: '12px',
                    px: 3,
                    textTransform: 'none',
                    fontWeight: 700,
                  }}
                >
                  Login
                </Button>
              </>
            )}
          </Box>
        </Toolbar>
      </Container>
    </AppBar>
  );
};

export default Navbar;