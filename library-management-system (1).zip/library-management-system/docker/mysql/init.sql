-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS library_db;
USE library_db;

-- Insert some sample data
INSERT INTO books (title, author, isbn, genre, publication_year, description, available, created_at) VALUES
('The Great Gatsby', 'F. Scott Fitzgerald', '978-0-7432-7356-5', 'Fiction', 1925, 'A classic American novel about the Jazz Age', true, CURDATE()),
('To Kill a Mockingbird', 'Harper Lee', '978-0-06-112008-4', 'Fiction', 1960, 'A gripping tale of racial injustice and childhood innocence', true, CURDATE()),
('1984', 'George Orwell', '978-0-452-28423-4', 'Dystopian', 1949, 'A dystopian social science fiction novel', true, CURDATE()),
('Pride and Prejudice', 'Jane Austen', '978-0-14-143951-8', 'Romance', 1813, 'A romantic novel of manners', true, CURDATE()),
('The Catcher in the Rye', 'J.D. Salinger', '978-0-316-76948-0', 'Fiction', 1951, 'A controversial novel about teenage rebellion', true, CURDATE());

INSERT INTO members (name, email, phone_number, address, active, membership_date) VALUES
('John Doe', 'john.doe@example.com', '+1-555-0123', '123 Main St, Anytown, USA', true, CURDATE()),
('Jane Smith', 'jane.smith@example.com', '+1-555-0124', '456 Oak Ave, Somewhere, USA', true, CURDATE()),
('Bob Johnson', 'bob.johnson@example.com', '+1-555-0125', '789 Pine Rd, Elsewhere, USA', true, CURDATE()),
('Alice Brown', 'alice.brown@example.com', '+1-555-0126', '321 Elm St, Nowhere, USA', true, CURDATE());